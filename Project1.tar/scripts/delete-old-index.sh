#!/bin/bash

rm -rf /var/www/html/index.html
